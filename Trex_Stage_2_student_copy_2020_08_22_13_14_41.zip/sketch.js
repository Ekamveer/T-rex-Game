var trex, trex_running, trex_collided;
var ground, invisibleGround, groundImage;
var Obstacle1,Obstacle2,Obstacle3,Obstacle4,Obstacle5,Obstacle6,obstacleGroup;
var Cloud,cloudGroup;
var score;
var PLAY=1,END=0,gameState=PLAY;
var score=0,GameOver,Restart;

function preload(){
  trex_running = loadAnimation("trex1.png","trex3.png","trex4.png");
  trex_collided = loadImage("trex_collided.png");
  
  groundImage = loadImage("ground2.png")
  Obstacle1=loadImage("obstacle1.png")
  Obstacle2=loadImage("obstacle2.png")
  Obstacle3=loadImage("obstacle3.png")
  Obstacle4=loadImage("obstacle4.png") 
  Obstacle5=loadImage("obstacle5.png")  
  Obstacle6=loadImage("obstacle6.png") 
  
  Cloud=loadImage("cloud.png")
  
  GameOverimg=loadImage("gameOver.png")
  Restartimg=loadImage("restart.png")
}

function setup() {
  createCanvas(600, 200);
  
  trex = createSprite(50,180,20,50);
  trex.addAnimation("running", trex_running);
  trex.scale = 0.5;
  trex.addImage(trex_collided);
  
  ground = createSprite(200,180,400,20);
  ground.addImage("ground",groundImage);
  ground.x = ground.width /2;
  ground.velocityX = -2;
  
  invisibleGround = createSprite(200,190,400,10);
  invisibleGround.visible = false;
  
   cloudGroup=new Group();
  obstacleGroup=new Group();
  
  gameOver=createSprite(300,100);
  gameOver.addImage(GameOverimg);
  gameOver.scale=0.5;
  gameOver.visible=false;
  
  Restart=createSprite(300,150);
  Restart.addImage(Restartimg);
  Restart.scale=0.5;
    Restart.visible=false;
   score=0;
}

function draw() {
  background("darkgrey");
  
  
  text("Score: "+ score, 200, 50);
  
  if (gameState===PLAY){
  score = score + Math.round(getFrameRate()/60);
    
    
  if(keyDown("space")) {
    trex.velocityY = -10;
  }
  
    if (ground.x < 0){
    ground.x = ground.width/2;
    }
  
    trex.velocityY = trex.velocityY + 0.8
    
  if (obstacleGroup.isTouching(trex)){   
       gameState=END;
  
  
  }
    
    
    
    spawnObstacles();
    SpawnClouds();
}
  
  
  if (gameState===END){
  
    gameOver.visible=true;
    Restart.visible=true;
  ground.velocityX=0;
  cloudGroup.setVelocityEach(0,0);
  obstacleGroup.setVelocityEach(0,0);  
  score=0;
   trex.changeAnimation( "run",trex_collided); 
    
  cloudGroup.setLifetimeEach(-1);
  obstacleGroup.setLifetimeEach(-1);  
    
    
    
    
   if( mousePressedOver(Restart)){
     reset();
    
  }
  } 

  trex.collide(invisibleGround);
  
  
  
  drawSprites();



function SpawnClouds(){
  
  if (frameCount%60===0){
  
  var cloud = createSprite(600,120,40,10);
    cloud.y = Math.round(random(80,120));
    cloud.addImage(Cloud);
    cloud.scale = 0.5;
    cloud.velocityX = -3;
    
     //assign lifetime to the variable
    cloud.lifetime = 200;
    
    cloudGroup.add(cloud);
    
  }
}



function spawnObstacles() {
  if(frameCount % 60 === 0) {
    var obstacle = createSprite(600,165,10,40);
    obstacle.velocityX = -6;
    
    //generate random obstacles
    var rand = Math.round(random(1,6));
    
    switch(rand)
    {
      case 1: obstacle.addImage(Obstacle1);
      break;
      case 2: obstacle.addImage(Obstacle2);
      break;
      case 3: obstacle.addImage(Obstacle3);
      break;
     case 4: obstacle.addImage(Obstacle4);
      break; 
      case 5: obstacle.addImage(Obstacle5);
      break;
      case 6: obstacle.addImage(Obstacle6);
      break;
      default:break;
    }
    //assign scale and lifetime to the obstacle           
    obstacle.scale = 0.5;
    obstacle.lifetime = 100;
    obstacleGroup.add(obstacle);
  }
}     
  
  


function reset(){
gameState = PLAY;
  
  gameOver.visible = false;
  Restart.visible = false;
  
  obstacleGroup.destroyEach();
  cloudGroup.destroyEach();
  
  trex.changeAnimation("running",trex_running);
  
  count = 0;
}
  
} 
  
  
  


